from flask import Flask, request, send_from_directory, abort, Response
import asyncio
import edge_tts
import uuid
import os
import subprocess

app = Flask(__name__)

VOICE = "bn-IN-BashkarNeural"

# Folder to store the generated audio files
AUDIO_DIR = os.path.join(os.getcwd(), 'audio_files')
os.makedirs(AUDIO_DIR, exist_ok=True)

# Path to ffmpeg.exe (assumed to be in the same directory)
FFMPEG_PATH = os.path.join(os.getcwd(), "ffmpeg.exe")

async def synthesize(text, output_path):
    communicate = edge_tts.Communicate(text, VOICE)
    await communicate.save(output_path)

def convert_to_pcm(input_path, output_path):
    """Use ffmpeg.exe via subprocess to convert WAV to PCM 16-bit 8000Hz"""
    command = [
        FFMPEG_PATH,
        "-y",  # Overwrite output file if exists
        "-i", input_path,
        "-ar", "8000",        # Set sample rate to 8000 Hz
        "-ac", "1",           # Mono channel
        "-sample_fmt", "s16", # 16-bit signed PCM
        output_path
    ]

    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    if result.returncode != 0:
        raise Exception(f"ffmpeg conversion failed: {result.stderr.decode()}")

@app.route("/speak", methods=["GET"])
def speak():
    text = request.args.get("text")
    if not text:
        return abort(400, description="Missing 'text' parameter")

    # File paths
    filename = f"{uuid.uuid4()}.wav"
    temp_output_path = os.path.join(AUDIO_DIR, filename)
    final_output_path = os.path.join(AUDIO_DIR, f"pcm_{filename}")

    try:
        # Synthesize TTS
        asyncio.run(synthesize(text, temp_output_path))

        # Convert to PCM format using ffmpeg
        convert_to_pcm(temp_output_path, final_output_path)

        # Remove original non-PCM file
        os.remove(temp_output_path)

        # Open and send the PCM audio file as response
        with open(final_output_path, 'rb') as audio_file:
            return Response(audio_file.read(), mimetype="audio/wav")

    except Exception as e:
        return abort(500, description=f"Server error: {e}")

@app.route("/audio/<filename>")
def serve_audio(filename):
    try:
        return send_from_directory(AUDIO_DIR, filename)
    except FileNotFoundError:
        return abort(404, description="Audio file not found")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1245, debug=True)
