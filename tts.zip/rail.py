from flask import Flask, request, jsonify, Response
import requests
import uuid
import os
import subprocess
import asyncio
import edge_tts
from datetime import datetime

app = Flask(__name__)

# Voice settings
VOICE = "bn-IN-BashkarNeural"

# Folder to store the generated audio files
AUDIO_DIR = os.path.join(os.getcwd(), 'audio_files')
os.makedirs(AUDIO_DIR, exist_ok=True)

# Path to ffmpeg.exe (assumed to be in the same directory)
FFMPEG_PATH = os.path.join(os.getcwd(), "ffmpeg.exe")

# Helper function to convert timestamp to AM/PM format
def convert_to_am_pm(timestamp):
    try:
        dt_object = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
        return dt_object.strftime("%I:%M %p, %d-%m-%Y")  # Returns time in AM/PM format
    except ValueError:
        return timestamp


# Function to synthesize text to speech
async def synthesize(text, output_path):
    communicate = edge_tts.Communicate(text, VOICE)
    await communicate.save(output_path)

# Function to convert audio to PCM format using ffmpeg
def convert_to_pcm(input_path, output_path):
    """Use ffmpeg.exe via subprocess to convert WAV to PCM 16-bit 8000Hz"""
    command = [
        FFMPEG_PATH,
        "-y",  # Overwrite output file if exists
        "-i", input_path,
        "-ar", "8000",        # Set sample rate to 8000 Hz
        "-ac", "1",           # Mono channel
        "-sample_fmt", "s16", # 16-bit signed PCM
        output_path
    ]

    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    if result.returncode != 0:
        raise Exception(f"ffmpeg conversion failed: {result.stderr.decode()}")

@app.route('/train_info', methods=["GET"])
def train_info():
    train_no = request.args.get('train_no')
    if not train_no:
        return jsonify({"error": "Please enter 'train_no' parameter!"})

    xd = requests.get(f"https://siamloc-rail.vercel.app/?train_no={train_no}")
    vv = xd.json()["ivr_announcement"]


    # File paths
    filename = f"{uuid.uuid4()}.wav"
    temp_output_path = os.path.join(AUDIO_DIR, filename)
    final_output_path = os.path.join(AUDIO_DIR, f"pcm_{filename}")

    try:
        # Synthesize TTS
        asyncio.run(synthesize(vv, temp_output_path))

        # Convert to PCM format using ffmpeg
        convert_to_pcm(temp_output_path, final_output_path)

        # Remove original non-PCM file
        os.remove(temp_output_path)

        # Open and send the PCM audio file as response
        with open(final_output_path, 'rb') as audio_file:
            return Response(audio_file.read(), mimetype="audio/wav")

    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1245, debug=True)